export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-card rounded-lg shadow-lg p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="text-3xl font-bold text-primary mb-2">GoLiv</div>
            <p className="text-muted-foreground">Buy, Sell & Hire Locally</p>
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
