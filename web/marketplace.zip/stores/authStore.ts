import { create } from 'zustand';
import { User, AuthResponse } from '@/types';

interface AuthStore {
  user: User | null;
  accessToken: string | null;
  isLoading: boolean;
  error: string | null;

  // Actions
  setAuth: (data: AuthResponse) => void;
  setUser: (user: User) => void;
  setAccessToken: (token: string) => void;
  logout: () => void;
  setError: (error: string | null) => void;
  setLoading: (loading: boolean) => void;
  isAuthenticated: () => boolean;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user: null,
  accessToken: null,
  isLoading: false,
  error: null,

  setAuth: (data: AuthResponse) => {
    set({
      user: data.user,
      accessToken: data.accessToken,
      error: null,
    });
  },

  setUser: (user: User) => {
    set({ user });
  },

  setAccessToken: (token: string) => {
    set({ accessToken: token });
  },

  logout: () => {
    set({
      user: null,
      accessToken: null,
      error: null,
    });
  },

  setError: (error: string | null) => {
    set({ error });
  },

  setLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  isAuthenticated: () => {
    const { user, accessToken } = get();
    return !!user && !!accessToken;
  },
}));
